# WEBBER

> View websites locally !

Easily download a website (all web pages) and store them for later offline usage !
Scrape websites till any depth you want ranging from just a single domain download to multiple ones !

It searches all links and downloads everything right into your computer so that you can access them later again.

> ONLY FOR EDUCATIONAL PURPOSES
